import './App.css'
import RouterComp from './router/RouterComp';

export default function App() {
  return (
    <RouterComp />
  )
}
