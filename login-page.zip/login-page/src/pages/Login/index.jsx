import './styles.css'
import InputForm from '../../components/InputForm'
// import { useNavigate } from 'react-router-dom'

const Login = () => {
  // const navigate = useNavigate()

  return (
    <div className="container-login">
      <div className="container-image"></div>
      <div className="container-form-login">
        <div className="header-title">
          <h1>Login</h1>
          <p className="desc">Welcome! You need to login to access the site content.</p>
        </div>

        <form>
          <InputForm
            textValue="E-mail"
            type="email"
            name="email-text"
            id="email-text"
            required={true}
          />

          <InputForm
            textValue="Password"
            type="password"
            name="password-text"
            id="password-text"
          />

          <button type="submit">SignIn</button>
        </form>

        <div className="container-nav">
          <p>New User? <a className='signup-a a-text' href="/register">SignUp</a></p>
          <a className='a-text' href='#'>Forgot your password?</a>
        </div>
      </div>
    </div>
  )
}

export default Login
