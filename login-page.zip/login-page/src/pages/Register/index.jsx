import './styles.css'
import InputForm from '../../components/InputForm'
import { useNavigate } from 'react-router-dom'
import { useState } from 'react'

const Register = () => {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  function validate_info_input() {
    if (password != confirmPassword) {
      return
    } else {
      // connect with firebase, to create account
      navigate("/");
    }
  }

  return (
    <div className="container-register">
      <div className="container-image"></div>
      <div className="container-form-register">
        <div className="header-title">
          <h1>Register</h1>
          <p className="desc">Create your account, to have acess the content all.</p>
        </div>

        <form>
          <InputForm
            textValue="E-mail"
            type="email"
            name="email-text"
            id="email-text"
            required={true}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />

          <InputForm
            textValue="Password"
            type="password"
            name="password-text"
            id="password-text"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />

          <InputForm
            textValue="Confirm your password"
            type="password"
            name="password-confirm-text"
            id="password-confirm-text"
            value={confirmPassword}
            onChange={(event) => setConfirmPassword(event.target.value)}
          />

          <button type="submit" onClick={validate_info_input}>Create</button>
        </form>

        <div className="container-nav">
          <p>Already have an account? <a className='signup-a a-text' href="/">SignIn</a></p>
        </div>
      </div>
    </div>
  )
}

export default Register
