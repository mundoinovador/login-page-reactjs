import './styles.css'

const Home = () => {
  return (
    <div className="container-home">
      <h1 style={{color: 'blueviolet', fontSize: 50}}>Home</h1>
      <button>Sair</button>
    </div>
  )
}

export default Home
