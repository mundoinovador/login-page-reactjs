import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from '../pages/Login/index';
import Home from '../pages/Home/index';
import Register from "../pages/Register";

export default function RouterComp() {
  return (
    <BrowserRouter>
      <Routes>
        <Route index element={<Login />} />
        <Route path="/home" element={<Home />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </BrowserRouter>
  )
}
